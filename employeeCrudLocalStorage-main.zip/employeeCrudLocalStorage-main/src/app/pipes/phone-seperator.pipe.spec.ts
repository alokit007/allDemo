import { PhoneSeperatorPipe } from './phone-seperator.pipe';

describe('PhoneSeperatorPipe', () => {
  it('create an instance', () => {
    const pipe = new PhoneSeperatorPipe();
    expect(pipe).toBeTruthy();
  });
});
